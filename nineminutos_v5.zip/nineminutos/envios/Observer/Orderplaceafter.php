<?php

 namespace nineminutos\envios\Observer;

 use Magento\Framework\Event\ObserverInterface;
 use Psr\Log\LoggerInterface;
 
 class Orderplaceafter implements ObserverInterface
 {
     protected $logger;

     protected $_scopeConfig;

     protected $_cart;
 
     public function __construct(LoggerInterface$logger, \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, \Magento\Checkout\Model\Cart $cartModel) {

         $this->logger = $logger;

         $this->_scopeConfig = $scopeConfig;

         $this->_cart = $cartModel;
     }
 
     public function execute(\Magento\Framework\Event\Observer $observer){

      $items = $this->_cart->getQuote()->getAllItems();

      $weight = 0;

      foreach($items as $item)
          {
              $weight += ($item->getWeight() * $item->getQty()) ;        
          }


          try {

              $order = $observer->getEvent()->getOrder(); 
            }

           catch(\Exception $e){
              $this->logger->info($e->getMessage());
          }

          $apikey =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/apikey', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

          $name_method =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/name_method', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

          $notes =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/notes', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

           $seller_name =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/seller_name', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

           $lastname =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/lastname', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

           $emailSender =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/emailSender', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

           $phoneSender =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/phoneSender', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

           $addressOrigin =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/addressOrigin', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

           $numberOrigin =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/numberOrigin', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

           $codePostalOrigin =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/codePostalOrigin', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

          $ch = curl_init();

          curl_setopt($ch, CURLOPT_URL, "https://deploy-dot-precise-line-76299minutos.appspot.com/api/v1/autorization/order");
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
          curl_setopt($ch, CURLOPT_HEADER, FALSE);

          curl_setopt($ch, CURLOPT_POST, TRUE);

          curl_setopt($ch, CURLOPT_POSTFIELDS, "{
            \"apikey\": \"{$apikey}\",
            \"deliveryType\": \"{$name_method}\",
            \"packageSize\": \"m\",
            \"notes\": \"{$notes}\",
            \"cahsOnDelivery\": true,
            \"amountCash\": \"{$weight}\",
            \"SecurePackage\": false,
            \"amountSecure\": 0,
            \"receivedId\": \"\",
            \"origin\": {
              \"sender\": \"'{$seller_name} . {$lastname}'\",
              \"nameSender\": \"{$seller_name}\",
              \"lastNameSender\": \"{$lastname}\",
              \"emailSender\": \"{$emailSender}\",
              \"phoneSender\": \"{$phoneSender}\",
              \"addressOrigin\": \"{$addressOrigin}\",
              \"numberOrigin\": \"{$numberOrigin}\",
              \"codePostalOrigin\": \"{$codePostalOrigin}\",
              \"country\": \"MEX\"
            },
            \"destination\": {
              \"receiver\": \"{$order->getShippingAddress()->getData('firstname')} . {$order->getShippingAddress()->getData('lastname')}\",
              \"nameReceiver\": \"{$order->getShippingAddress()->getData('firstname')}\",
              \"lastNameReceiver\": \"{$order->getShippingAddress()->getData('lastname')}\",
              \"emailReceiver\": \"{$order->getShippingAddress()->getData('email')}\",
              \"phoneReceiver\": \"{$order->getShippingAddress()->getData('telephone')}\",
              \"addressDestination\": \"{$order->getShippingAddress()->getData('street')} . {$order->getShippingAddress()->getData('city')} . {$order->getShippingAddress()->getData('postcode')}\",
              \"numberDestination\": \"238\",
              \"codePostalDestination\": \"{$order->getShippingAddress()->getData('postcode')}\",
              \"country\": \"MEX\"
            }
          }");

          curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "Content-Type: application/json"
          ));

          $response = curl_exec($ch);
          curl_close($ch);
                }
          }