<?php
 
namespace nineminutos\envios\Observer;
 
use Magento\Framework\Event\ObserverInterface;
 
class Cartweight implements ObserverInterface
{
    protected $_cart;

    public function __construct(\Magento\Checkout\Model\Cart $cartModel)
        {
        $this->_cart = $cartModel;
        }
 
    /**
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $items = $this->_cart->getQuote()->getAllItems();

        $weight = 0;

        foreach($items as $item)
            {
                $weight += ($item->getWeight() * $item->getQty()) ;        
            }

        $product = $observer->getProduct();
 
        $originalName = $product->getName();
 
        $modifiedName = $originalName . ' - MODIFICADO POR EL OBSERVER' . $weight;
 
        $product->setName($modifiedName);
    }
 
}