<?php

 namespace nineminutos\envios\Observer;
 
 use Magento\Framework\Event\ObserverInterface;
 use Psr\Log\LoggerInterface;
 
 class Orderplaceafter implements ObserverInterface
 {
     protected $logger;

     protected $_scopeConfig;
 
     public function __construct(LoggerInterface$logger, \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig) {

         $this->logger = $logger;
         $this->_scopeConfig = $scopeConfig;
     }
 
     public function execute(\Magento\Framework\Event\Observer $observer){

          try {

              $order = $observer->getEvent()->getOrder(); 
            }

           catch(\Exception $e){
              $this->logger->info($e->getMessage());
          }

          $apikey =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/apikey', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

          $name_method =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/name_method', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

          $packageSize =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/packageSize', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

          $notes =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/notes', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

           $name =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/name', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

           $lastname =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/lastname', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

           $emailSender =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/emailSender', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

           $phoneSender =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/phoneSender', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

           $addressOrigin =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/addressOrigin', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

           $numberOrigin =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/numberOrigin', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

           $codePostalOrigin =  $this->_scopeConfig->getValue('carriers/nineminutos_envios/codePostalOrigin', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

          $ch = curl_init();

          curl_setopt($ch, CURLOPT_URL, "https://deploy-dot-precise-line-76299minutos.appspot.com/api/v1/autorization/order");
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
          curl_setopt($ch, CURLOPT_HEADER, FALSE);

          curl_setopt($ch, CURLOPT_POST, TRUE);

          curl_setopt($ch, CURLOPT_POSTFIELDS, "{
            \"apikey\": \"{$apikey}\",
            \"deliveryType\": \"{$name_method}\",
            \"packageSize\": \"m\",
            \"notes\": \"{$notes}\",
            \"cahsOnDelivery\": true,
            \"amountCash\": 666,
            \"SecurePackage\": false,
            \"amountSecure\": 0,
            \"receivedId\": \"\",
            \"origin\": {
              \"sender\": \"{$name}\",
              \"nameSender\": \"{$name}\",
              \"lastNameSender\": \"{$lastname}\",
              \"emailSender\": \"{$emailSender}\",
              \"phoneSender\": \"{$phoneSender}\",
              \"addressOrigin\": \"{$addressOrigin}\",
              \"numberOrigin\": \"{$numberOrigin}\",
              \"codePostalOrigin\": \"{$codePostalOrigin}\",
              \"country\": \"MEX\"
            },
            \"destination\": {
              \"receiver\": \"{$order->getShippingAddress()->getData('firstname')} . {$order->getShippingAddress()->getData('lastname')}\",
              \"nameReceiver\": \"{$order->getShippingAddress()->getData('firstname')}\",
              \"lastNameReceiver\": \"{$order->getShippingAddress()->getData('lastname')}\",
              \"emailReceiver\": \"{$order->getShippingAddress()->getData('email')}\",
              \"phoneReceiver\": \"{$order->getShippingAddress()->getData('telephone')}\",
              \"addressDestination\": \"{$order->getShippingAddress()->getData('street')} . {$order->getShippingAddress()->getData('city')} . {$order->getShippingAddress()->getData('postcode')}\",
              \"numberDestination\": \"238\",
              \"codePostalDestination\": \"{$order->getShippingAddress()->getData('postcode')}\",
              \"country\": \"MEX\"
            }
          }");

          curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "Content-Type: application/json"
          ));

          $response = curl_exec($ch);
          curl_close($ch);
                }
          }